//
//  ViewController.m
//  logoReplace
//
//  Created by wql on 2017/12/19.
//  Copyright © 2017年 wql. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)one:(id)sender {
    [self changeImageNames:@"icon1"];
}

- (IBAction)two:(id)sender {
    [self changeImageNames:@"icon2"];
}


-(void)changeImageNames:(NSString *)name{
    
    if ([UIApplication sharedApplication].supportsAlternateIcons) {//来判断是否支持换应用图标
        
        //setAlertnateIconName方法有二个参数
        //第一个参数是要换图标的名字(此名字不是图片的原始名字)，如果写nil，系统默认是最初图标名字
        //第二个参数是方法执行的回调
        [[UIApplication sharedApplication] setAlternateIconName:name completionHandler:^(NSError *_Nullable error) {
            if (error) {
                NSLog(@"失败");
            }else{
                NSLog(@"成功");
            }
            
        }];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
